//
//  main.m
//  MultiGrowl
//
//  Created by Rudy Richter on 11/8/11.
//  Copyright 2011 The Growl Project, LLC. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
