//
//  GrowlFadingWindowTransition.h
//  Growl
//
//  Created by Ofri Wolfus on 27/07/05.
//  Copyright 2005-2006 The Growl Project. All rights reserved.
//

#import <GrowlPlugins/GrowlWindowtransition.h>

@interface GrowlFadingWindowTransition : GrowlWindowTransition {
}

@end
