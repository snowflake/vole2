//
//  ___FILENAME___
//  ___PACKAGENAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright (c) ___YEAR___ ___ORGANIZATIONNAME___. All rights reserved.
//

#import <GrowlPlugins/GrowlPluginPreferencePane.h>

@interface Growl___PACKAGENAME___PreferencePane : GrowlPluginPreferencePane

@end
